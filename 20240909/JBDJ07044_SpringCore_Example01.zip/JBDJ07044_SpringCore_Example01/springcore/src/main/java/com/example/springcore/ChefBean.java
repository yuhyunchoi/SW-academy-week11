package com.example.springcore;

import org.springframework.stereotype.Component;

@Component
class ChefBean {
    public void cook(){
        System.out.println("cook");
    }
}
