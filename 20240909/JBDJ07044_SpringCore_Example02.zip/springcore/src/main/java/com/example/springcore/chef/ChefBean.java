package com.example.springcore.chef;

public interface ChefBean {
    void cook();
}
