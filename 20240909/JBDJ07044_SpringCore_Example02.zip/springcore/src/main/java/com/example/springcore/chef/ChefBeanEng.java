package com.example.springcore.chef;


import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

@Profile("eng")
@Component
public class ChefBeanEng implements ChefBean {
    @Value("${chef.cook}")
    private String cook;
    public void cook(){
        System.out.println(cook);
    }
}
