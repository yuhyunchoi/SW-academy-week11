package com.example.springcore.deliver;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

@Profile("eng")
@Component
public class DeliveryServiceBeanEng implements DeliveryServiceBean{

    private final DeliveryServiceProperties deliveryServiceProperties;

    public DeliveryServiceBeanEng(DeliveryServiceProperties deliveryServiceProperties) {
        this.deliveryServiceProperties = deliveryServiceProperties;
    }

    public void deliver(){
        System.out.println(deliveryServiceProperties.getMessageEng());
    }
}
