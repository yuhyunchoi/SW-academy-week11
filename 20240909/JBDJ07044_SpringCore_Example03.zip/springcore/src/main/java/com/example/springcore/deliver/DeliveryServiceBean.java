package com.example.springcore.deliver;

public interface DeliveryServiceBean {
    void deliver();
}
